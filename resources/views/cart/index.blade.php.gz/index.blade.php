@extends('layouts.front')
@section('content')
    <section id="cart">
        <div class="container">
            <div class="cart_container">
                <div class="cart">
                    <div class="cart_content">
                        <div class="row d-flex align-items-center h-100">
                            <div class="col-12">

                                <div class="d-flex justify-content-between align-items-center">
                                    <h1 class="cart_h1">Заказ</h1>
                                </div>

                                @if ($items->isEmpty() && !$success)
                                    <div>
                                        Пожалуйста, добавьте товары в корзину из нашего каталога.
                                    </div>
                                @endif

                                @if ($success)
                                    <div>
                                        Заказ успешно сформирован.
                                    </div>
                                @else
                                    <div>{{ $message }}</div>
                                @endif

                                <div id="cart-items">
                                    @foreach ($items as $item)
                                        <div class="card rounded-3" id="item-{{ $item['product']->id }}">
                                            <div class="card-body">
                                                <div class="row d-flex justify-content-between align-items-center">
                                                    <div class="col-md-1 col-lg-1 col-xl-1 text-center closer_box">
                                                        <button onclick="removeItem({{ $item['product']->id }})" style="appearance: none;border:none;background: transparent;" class="text-danger closer">
                                                            <img src="images/close_cart.png" alt="">
                                                        </button>
                                                    </div>
                                                    @if (isset($item['product']->image_path))
                                                        <div class="col-md-1 col-lg-1 col-xl-1 col-2">
                                                            <div class="cart_img_box">
                                                                <img src="{{ asset('storage/' . $item['product']->image_path) }}" class="img-fluid rounded-3 cart_img">
                                                            </div>
                                                        </div>
                                                    @else
                                                        <div class="col-md-1 col-lg-1 col-xl-1 col-2">
                                                            <div class="cart_img_box">
                                                                <img src="/images/plug.png" class="img-fluid rounded-3 cart_img">
                                                            </div>
                                                        </div>
                                                    @endif

                                                    <div class="col-md-5 col-lg-5 col-xl-5 col-10">
                                                        <p class="cart_zag">{{ $item['product']->name }}</p>

                                                    </div>
                                                    <div class="col-md-3 col-lg-2 col-xl-2 col-4">
                                                        <h5 class="mb-0 cart_price">150 р/шт</h5>
                                                    </div>

                                                    <div class="col-md-3 col-lg-3 col-xl-3 d-flex cart_forms col-3">

                                                        <input min="0" name="quantity" id="product-{{ $item['product']->id }}-quantity" value="{{ $item['amount'] }}" type="number" class="form-control product-quantity form-control-sm" />
                                                        <div class="buttons-section">
                                                            <button class="increment footer-button" onclick="incrementProductQuantity({{ $item['product']->id }})" data-action="increment"></button>
                                                            <button class="decrement footer-button" onclick="decrementProductQuantity({{ $item['product']->id }})" data-action="decrement"></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                @if ($items->isNotEmpty() && !$success)
                    <form action="{{ route('pages.submit-cart') }}" method="POST">
                        @csrf
                        <div class="cart_contact">
                            <h2 class="cart_h2">
                                Реквизиты
                            </h2>
                            <div class="cart_contact_box">
                                <div class="form-group row">
                                    <label for="ur" class="col-sm-3 col-form-label">Юридическое лицо*</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control required" id="ur" name="ur" value="{{ old('ur', '') }}" required placeholder="">
                                        @error('ur')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inn" class="col-sm-3 col-form-label">ИНН*</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="inn" name="inn" value="{{ old('inn', '') }}" placeholder="" required>
                                        @error('inn')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                @if (false)
                                    <div class="form-group row">
                                        <label for="ogrn" class="col-sm-3 col-form-label">ОГРН*</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="ogrn" name="ogrn" value="{{ old('ogrn', '') }}" placeholder="" required>
                                            @error('ogrn')
                                                <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                @endif
                                <div class="form-group row">
                                    <label for="uradr" class="col-sm-3 col-form-label">Юридический адрес*</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="uradr" name="uradr" value="{{ old('uradr', '') }}" placeholder="" required>
                                        @error('uradr')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="bank" class="col-sm-3 col-form-label">Банк*</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="bank" name="bank" value="{{ old('bank', '') }}" placeholder="" required>
                                        @error('bank')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="bik" class="col-sm-3 col-form-label">БИК*</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="bik" name="bik" value="{{ old('bik', '') }}" placeholder="" required>
                                        @error('bik')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="chet" class="col-sm-3 col-form-label">Расчетный счет*</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="chet" name="chet" value="{{ old('chet', '') }}" placeholder="" required>
                                        @error('chet')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-check text-right">
                                        <label class="form-check-label" id="need_delivery_l" for="need_delivery">
                                            Нужна доставка
                                        </label>
                                        <input onclick="needDelivery()" class="form-check-input" type="checkbox" name="need_delivery" id="need_delivery">
                                    </div>
                                </div>
                                <div class="form-group row form-group-delivery" style="display: none;">
                                    <label for="delivery" class="col-sm-3 col-form-label">Адрес доставки</label>
                                    <div class="col-sm-9">
                                        <textarea class="form-control" id="delivery" name="delivery" rows="3">{{ old('delivery', '') }}</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="cart_contact">
                            <h2 class="cart_h2">
                                Контактное лицо
                            </h2>
                            <div class="cart_contact_box">
                                <div class="form-group row">
                                    <label for="name" class="col-sm-3 col-form-label">Имя*</label>
                                    <div class="col-sm-9">
                                        <input type="text" required class="form-control" id="name" name="name" value="{{ old('name', '') }}" placeholder="">
                                        @error('name')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="phone" class="col-sm-3 col-form-label">Телефон*</label>
                                    <div class="col-sm-9">
                                        <input type="text" required class="form-control" id="phone" name="phone" value="{{ old('phone', '') }}" placeholder="">
                                        @error('phone')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="email" class="col-sm-3 col-form-label">E-mail*</label>
                                    <div class="col-sm-9">
                                        <input type="text" required class="form-control" id="email" name="email" value="{{ old('email', '') }}" placeholder="">
                                        @error('email')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="comment" class="col-sm-3 col-form-label">Комментарий</label>
                                    <div class="col-sm-9">
                                        <textarea class="form-control" id="comment" name="comment" rows="3">
                                {{ old('comment', '') }}
                                </textarea>
                                        @error('comment')
                                            <div style="margin-top: -6px;font-size: 14px;color: red;">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="form-check text-right">
                                        <label class="form-check-label" for="need_call">
                                            Нужно созвониться
                                        </label>
                                        <input class="form-check-input" type="checkbox" name="need_call" id="need_call">
                                    </div>
                                </div>
                                <div class="form-group text-center">
                                    <div class="submit">
                                        <a href="{{ route('cart.download') }}" style="{{ session()->has('cart') && !count(session()->get('cart')) ? 'pointer-events: none;' : '' }}" class="btn btn-secondary">Сохранить список</a>
                                        {{-- <button type="button" class="btn btn-secondary">Добавить из списка</button> --}}
                                        <button type="button" class="btn btn-secondary cart-upload">Загрузить список</button>
                                        <button type="submit" class="btn btn-primary">Отправить запрос</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                @endif

            </div>
        </div>
    </section>

@endsection

@section('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            $.ajax({
                url: "/api/cart",
                type: "GET",
                dataType: 'json',
                xhrFields: {
                    withCredentials: true
                },
                success: function(data) {
                    updateProductsQuantity(data, true);
                },
            });

            $('.product-quantity').each(function() {
                const productId = parseInt($(this).attr('id').replace('product-', '').replace('-quantity', ''));
                $(this).on('change', e => {
                    if (parseInt(e.target.value) <= 0) {
                        const element = document.getElementById(`item-${productId}`);
                        element.outerHTML = '';
                    }
                    send(productId, parseInt(e.target.value));
                });
            });
        });

        $(document).ready(function() {
            $('.cart-upload').click(function(e) {
                e.preventDefault();
                const form = $('#cart-upload-form');
                const input = form.find('input[type=file]');
                input.click();
            });
        });

        function needDelivery() {
            const input = document.getElementById('need_delivery');
            const delivery = document.getElementsByClassName('form-group-delivery')[0];
            input.checked ? delivery.setAttribute('style', 'display: flex;') : delivery.setAttribute('style', 'display: none;');
        };

        function updateProductsQuantity(data, firstLoad = false) {
            if (data.quantity == 0 && !firstLoad) {
                window.location.href = "{{ route('pages.cart') }}";
                return;
            }
            $('.product-quantity').each(function() {
                $(this).val('0');
            });
            for (const item of data.items) {
                const input = document.getElementById(`product-${item.product_id}-quantity`);
                if (input) {
                    input.value = item.amount;
                }
            }

            $('.num_cart').text(data.quantity);
        }

        function removeItem(id) {
            const element = document.getElementById(`item-${id}`);
            element.outerHTML = '';
            send(id, 0);
        }

        function incrementProductQuantity(productId) {
            const input = document.getElementById(`product-${productId}-quantity`);
            const newValue = parseInt(input.value) + 1;
            input.value = newValue
            send(productId, newValue);
        }

        function decrementProductQuantity(productId) {
            const input = document.getElementById(`product-${productId}-quantity`);
            const newValue = parseInt(input.value) - 1;
            input.value = newValue
            if (newValue <= 0) {
                const element = document.getElementById(`item-${productId}`);
                element.outerHTML = '';
            }
            send(productId, newValue);
        }

        function send(productId, quantity) {
            $.ajax({
                url: "/api/cart",
                type: "POST",
                dataType: 'json',
                data: {
                    _token: '{{ csrf_token() }}',
                    product_id: productId,
                    quantity: quantity,
                },
                xhrFields: {
                    withCredentials: true
                },
                success: function(data) {
                    updateProductsQuantity(data);
                },
            });
        }
    </script>
@endsection
